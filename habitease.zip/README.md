# HabitEase – Daily Habit Tracker

HabitEase is a Flutter-based productivity app designed to help users build good habits and stay consistent through reminders, analytics, and gamification.

## 🚀 Features
- Create & Manage Habits
- Track Streaks and Completion Analytics
- Firebase Sync + Offline Support
- Reward System with Badges
- Animated UI with Lottie and Hero Widgets

## 🛠️ Tech Stack
Flutter, Dart, Firebase, Hive, Provider
